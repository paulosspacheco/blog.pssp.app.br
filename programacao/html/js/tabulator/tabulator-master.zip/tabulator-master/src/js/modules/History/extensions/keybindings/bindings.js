export default {
	undo:["ctrl + 90", "meta + 90"],
	redo:["ctrl + 89", "meta + 89"],
};
