export default {
	rangeJumpUp:["ctrl + 38", "meta + 38"],
	rangeJumpDown:["ctrl + 40", "meta + 40"],
	rangeJumpLeft:["ctrl + 37", "meta + 37"],
	rangeJumpRight:["ctrl + 39", "meta + 39"],
	rangeExpandUp:"shift + 38",
	rangeExpandDown:"shift + 40",
	rangeExpandLeft:"shift + 37",
	rangeExpandRight:"shift + 39",
	rangeExpandJumpUp:["ctrl + shift + 38", "meta + shift + 38"],
	rangeExpandJumpDown:["ctrl + shift + 40", "meta + shift + 40"],
	rangeExpandJumpLeft:["ctrl + shift + 37", "meta + shift + 37"],
	rangeExpandJumpRight:["ctrl + shift + 39", "meta + shift + 39"],
};
