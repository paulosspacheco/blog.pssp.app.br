export default {
	delete:function(fromRow, toRow, toTable){
		fromRow.delete();
	}
};