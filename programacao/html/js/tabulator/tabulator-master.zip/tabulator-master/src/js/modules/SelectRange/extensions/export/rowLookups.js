export default {
	range:function(){
		return this.modules.selectRange.selectedRows();
	},
};