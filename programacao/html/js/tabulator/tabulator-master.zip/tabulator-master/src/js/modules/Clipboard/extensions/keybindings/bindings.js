export default {
	copyToClipboard:["ctrl + 67", "meta + 67"],
};
