export default function (input){
	return input;
}