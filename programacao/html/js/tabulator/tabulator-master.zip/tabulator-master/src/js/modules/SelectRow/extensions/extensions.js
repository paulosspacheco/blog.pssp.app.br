import rowSelection from './formatters/rowSelection.js';

export default {
	format:{
		formatters:{
			rowSelection:rowSelection,
		}
	}
};