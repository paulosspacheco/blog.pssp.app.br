import responsiveCollapse from './formatters/responsiveCollapse.js';

export default {
	format:{
		formatters:{
			responsiveCollapse:responsiveCollapse,
		}
	}
};