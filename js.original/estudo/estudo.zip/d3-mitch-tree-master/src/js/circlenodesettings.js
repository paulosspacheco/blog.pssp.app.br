import NodeSettings from './NodeSettings';

class CircleNodeSettings extends NodeSettings {
}

export default CircleNodeSettings;