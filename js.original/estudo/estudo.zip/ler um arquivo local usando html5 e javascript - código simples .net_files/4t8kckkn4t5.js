if (self.CavalryLogger) { CavalryLogger.start_js(["LYXOQ"]); }

__d("DgwClientFalcoEvent",["FalcoLoggerInternal","getFalcoLogPolicy_DO_NOT_USE"],(function(a,b,c,d,e,f){"use strict";a=b("getFalcoLogPolicy_DO_NOT_USE")("1755537");c=b("FalcoLoggerInternal").create("dgw_client",a);e.exports=c}),null);