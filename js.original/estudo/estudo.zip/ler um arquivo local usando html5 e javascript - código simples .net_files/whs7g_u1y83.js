if (self.CavalryLogger) { CavalryLogger.start_js(["PAWM8"]); }

__d("DGWAuth",["$InternalEnum"],(function(a,b,c,d,e,f){"use strict";a=b("$InternalEnum")({TEST:"0:0",FACEBOOK:"1:0"});f.DGWAuth=a}),null);