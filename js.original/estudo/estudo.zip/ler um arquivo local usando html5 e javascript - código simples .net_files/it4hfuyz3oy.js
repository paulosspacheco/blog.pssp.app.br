if (self.CavalryLogger) { CavalryLogger.start_js(["UAUm6"]); }

__d("ThriftTypes",[],(function(a,b,c,d,e,f){a=Object.freeze({STOP:0,VOID:1,BOOL:2,BYTE:3,I08:3,DOUBLE:4,I16:6,I32:8,I64:10,STRING:11,STRUCT:12,MAP:13,SET:14,LIST:15,FLOAT:19});b=a;e.exports=b}),null);